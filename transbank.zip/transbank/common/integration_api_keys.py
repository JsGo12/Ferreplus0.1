# Contains the Webpay, Oneclick and Patpass Comercio constants for testing.
class IntegrationApiKeys(object):
    WEBPAY = "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C"
    PATPASS_COMERCIO = "cxxXQgGD9vrVe4M41FIt"

from fastapi import APIRouter, Form, Depends
from fastapi.responses import HTMLResponse
from transbank.webpay.webpay_plus.transaction import Transaction
from transbank.common.options import WebpayOptions
from transbank.common.integration_type import IntegrationType
from transbank.error.transbank_error import TransbankError
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models.payment import Payment

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/webpay", response_class=HTMLResponse)
async def index():
    return '''
        <h2>Pagar con Webpay Plus</h2>
        <form action="/webpay/pagar" method="post">
            <input type="submit" value="Pagar $1.000">
        </form>
    '''

@router.post("/webpay/pagar", response_class=HTMLResponse)
async def pagar(db: Session = Depends(get_db)):
    try:
        options = WebpayOptions(
            commerce_code="597055555532",
            api_key="XTYIgWHavV1dD3+nIhWsQJ6s+Xc=",
            integration_type=IntegrationType.TEST
        )

        tx = Transaction(options)

        response = tx.create(
            buy_order="orden1234",
            session_id="sesion1234",
            amount=1000,
            return_url="http://localhost:8000/webpay/retorno"
        )

        # Guardar en la BD
        db.add(Payment(
            orden_compra="orden1234",
            sesion_id="sesion1234",
            monto=1000,
            token=response['token'],
            estado="pendiente"
        ))
        db.commit()

        return f'''
            <form id="webpay-form" action="{response["url"]}" method="POST">
                <input type="hidden" name="token_ws" value="{response["token"]}" />
            </form>
            <script>document.getElementById('webpay-form').submit();</script>
        '''
    except TransbankError as e:
        return f"<h2>ERROR al crear transacción:</h2><pre>{str(e)}</pre>"


@router.post("/webpay/retorno", response_class=HTMLResponse)
async def retorno(token_ws: str = Form(...), db: Session = Depends(get_db)):
    try:
        options = WebpayOptions(
            commerce_code="597055555532",
            api_key="XTYIgWHavV1dD3+nIhWsQJ6s+Xc=",
            integration_type=IntegrationType.TEST
        )
        tx = Transaction(options)
        result = tx.commit(token_ws)

        pago = db.query(Payment).filter(Payment.token == token_ws).first()
        if pago:
            pago.estado = result["status"]
            db.commit()

        return f"""
            <h3>Resultado de la transacción</h3>
            <ul>
                <li>Estado: {result["status"]}</li>
                <li>Monto: {result["amount"]}</li>
                <li>Orden: {result["buy_order"]}</li>
                <li>Código de autorización: {result["authorization_code"]}</li>
            </ul>
            <a href="/">Volver</a>
        """
    except Exception as e:
        return f"<h2>Error al confirmar el pago:</h2><pre>{str(e)}</pre>"

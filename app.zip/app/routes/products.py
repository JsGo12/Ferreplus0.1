from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.models.product import Product
from app.database import SessionLocal
from app.dependencies import only_admin

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/products", summary="Listar todos los productos")
def listar_productos(db: Session = Depends(get_db)):
    return db.query(Product).all()

@router.post("/products", summary="Crear un nuevo producto", status_code=status.HTTP_201_CREATED)
def crear_producto(
    codigo_producto: str,
    marca: str,
    nombre: str,
    precio: float,
    stock: int,
    db: Session = Depends(get_db),
    user: dict = Depends(only_admin)
):
    existente = db.query(Product).filter(Product.codigo_producto == codigo_producto).first()
    if existente:
        raise HTTPException(status_code=400, detail="Producto ya existe")
    
    nuevo = Product(
        codigo_producto=codigo_producto,
        marca=marca,
        nombre=nombre,
        precio=precio,
        stock=stock
    )
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return nuevo

@router.delete("/products/{codigo}", summary="Eliminar producto por código")
def eliminar_producto(
    codigo: str,
    db: Session = Depends(get_db),
    user: dict = Depends(only_admin)
):
    producto = db.query(Product).filter(Product.codigo_producto == codigo).first()
    if not producto:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    
    db.delete(producto)
    db.commit()
    return {"detail": f"Producto con código {codigo} eliminado"}

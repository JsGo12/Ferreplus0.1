from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.models.user import User
from app.database import SessionLocal
from app.services.auth import verify_password, hash_password, create_access_token

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/login", summary="Iniciar sesión y obtener token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password):
        raise HTTPException(status_code=400, detail="Credenciales incorrectas")
    
    token = create_access_token(data={"sub": user.email, "rol": user.rol})
    return {"access_token": token, "token_type": "bearer"}

@router.post("/register", summary="Registrar nuevo usuario")
def register(nombre: str, email: str, password: str, rol: str = "usuario", db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if user:
        raise HTTPException(status_code=400, detail="El usuario ya existe")
    
    nuevo = User(
        nombre=nombre,
        email=email,
        password=hash_password(password),
        rol=rol
    )
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return {"detail": "Usuario creado correctamente"}

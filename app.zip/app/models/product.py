from sqlalchemy import Column, Integer, String, Float
from app.database import Base

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    codigo_producto = Column(String(50), unique=True, index=True)
    marca = Column(String(100))
    nombre = Column(String(200))
    precio = Column(Float)
    stock = Column(Integer)
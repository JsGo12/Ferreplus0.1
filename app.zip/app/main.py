import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "transbank")))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import Base, engine
from app.routes import products, auth, webpay

app = FastAPI(
    title="FERREMAS",
    description="API REST para gestión de productos, usuarios y pagos con WebPay",
    version="1.0.0"
)

Base.metadata.create_all(bind=engine)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(products.router)
app.include_router(auth.router)
app.include_router(webpay.router)

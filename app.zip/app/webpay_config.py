#from transbank.webpay.webpay_plus.transaction import Transaction

# Configura las credenciales de prueba para Webpay Plus

#Transaction.commerce_code = '597055555532'  # Código de comercio de prueba
#Transaction.api_key = 'XTYIgWHavV1dD3+nIhWsQJ6s+Xc='  # API Key secreta de prueba
#Transaction.integration_type = 'TEST'  # Usamos el modo de prueba (TEST)  
